hauteur = int(input("Entrez la hauteur: "))

if hauteur < 4:
    print("Hauteur incorrecte")
else:
    for i in range(1, hauteur + 1):
        ligne = ""
        for j in range(1, i + 1):
            pyramide = ligne + str(j) + " "
            ligne = pyramide
        print(" " * (hauteur - i) + ligne)