import random  # Importation du module random pour générer des nombres aléatoires
from operator import truth

#from operator import ifloordiv, truediv

# Génère un nombre entier aléatoire compris entre 10 et 100 inclus
#nombre_genere = random.randint(10, 100)

#Affiche le nombre entier aléatoire généré avec un message explicatif
#print(f"Le nombre aléatoire généré est : {nombre_genere}")




print("######################################")
print("IFT-1004 Airlines")
print("######################################")
print("La meilleure compagnie aérienne au monde!")
nombre_de_billet= int(input("Nombre de billet vous souheter reserver: "))
le_prix_fixe=150
somme=0
somme_total=0
for i in range(1, nombre_de_billet + 1):
    print("============")
    print("PASSAGER", i, "/", nombre_de_billet)
    print("============")
    nom = str(input("nom complet de passager: "))
    age = int(input("Age: "))
    print("nom de passager ",i," :", nom )
    print("Âge du passager ",i," :", age)
    rabais = random.randint(15, 55)
    if age <=3:
        le_prix= 0
        print("Prix du billet réservé pour",nom,"est:", le_prix,"$")
    elif age >= 65 :
        le_prix = le_prix_fixe-( le_prix_fixe* rabais/100)
        print("Rabais appliqué pour", nom, "est:", rabais,"%")
        print("Prix du billet réservé pour",nom,"est:", le_prix,"$")
    else:
        le_prix = le_prix_fixe
        print("Prix du billet réservé pour",nom,"est:", le_prix,"$")
        somme=somme+le_prix
    print("Montant total à encaisser pour cette réservation :",somme,"$")
choix=0
while choix!=2:
    print("1. Enregistrer un autre client")
    print("2.quitter")
    choix= int(input("Entrez votre choix : "))
    if choix==1 :
        print("redemarage de programme")
        print("######################################")
        print("IFT-1004 Airlines")
        print("######################################")
        print("La meilleure compagnie aérienne au monde!")
        nombre_de_billet = int(input("Nombre de billet vous souheter reserver: "))
        le_prix_fixe = 150
        somme = 0
        for i in range(1, nombre_de_billet + 1):
            print("============")
            print("PASSAGER", i, "/", nombre_de_billet)
            print("============")
            nom = str(input("nom complet de passager: "))
            age = int(input("Age: "))
            print("nom de passager ", i, " :", nom)
            print("Âge du passager ", i, " :", age)
            rabais = random.randint(15, 55)
            if age <= 3:
                le_prix = 0
                print("Prix du billet réservé pour", nom, "est:", le_prix, "$")
            elif age >= 65:
                le_prix = le_prix_fixe - (le_prix_fixe * rabais / 100)
                print("Rabais appliqué pour", nom, "est:", rabais, "%")
                print("Prix du billet réservé pour", nom, "est:", le_prix, "$")
            else:
                le_prix = le_prix_fixe
                print("Prix du billet réservé pour", nom, "est:", le_prix, "$")
            somme = somme + le_prix
            somme_total = somme_total + le_prix
            print("Montant total à encaisser pour cette réservation :", somme, "$")
    elif choix==2:
        print("Montant total cumulé pour tous les clients enregistrés : ",somme_total,"$","Bye bye!")
    else:
        print("Choix invalide, veuillez entrer 1 ou 2.")